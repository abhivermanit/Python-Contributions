class QuickSort:
    pass
